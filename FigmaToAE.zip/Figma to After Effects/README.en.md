# Figma → After Effects

## Figma plugin (3 tabs)
- **Perspective** — Skew (native, the layer stays vector) and Corner pin (4 corners, outputs an image layer).
- **Warp** — a 3×3 grid, outputs an image layer.
- **Export** — a summary and JSON export for After Effects.

Figma → Plugins → Development → Import plugin from manifest… → `figma-plugin/manifest.json`.
Select frames → Export to After Effects → `figma-to-ae.json` is downloaded.

## After Effects
Put `ae-script/FigmaToAE.jsx` into `Scripts/ScriptUI Panels`, turn on
Preferences → Scripting & Expressions → “Allow Scripts to Write Files…”, and open it from the Window menu.
Click “Import…” and choose the JSON. Each frame becomes its own composition.

## What comes across
- As native layers: rectangles (corner radius), ellipses, vectors/booleans/stars (paths), frames with fills, text (font, size, color, alignment, tracking), opacity, blend modes, rotation.
- As PNG rasters (so they look exactly like Figma): gradients, images, effects (shadows/blur), masks, **skew/perspective/mirroring** (Perspective and Warp results), mixed-style text, arcs.
- Not transferred: frame clip masks, auto-layout logic, animations.
