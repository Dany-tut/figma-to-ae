// Figma → After Effects importer.
// Установка: положить в Scripts/ScriptUI Panels и открыть из меню Window (панель),
// либо запускать через File > Scripts > Run Script File.
// Нужно: Preferences > Scripting & Expressions > Allow Scripts to Write Files and Access Network.
(function (thisObj) {
    var B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

    function decodeBase64(s) {
        var out = [], i, n = s.length, a, b, c, d;
        for (i = 0; i < n; i += 4) {
            a = B64.indexOf(s.charAt(i)); b = B64.indexOf(s.charAt(i + 1));
            c = B64.indexOf(s.charAt(i + 2)); d = B64.indexOf(s.charAt(i + 3));
            out.push(String.fromCharCode((a << 2) | (b >> 4)));
            if (c >= 0) out.push(String.fromCharCode(((b & 15) << 4) | (c >> 2)));
            if (d >= 0) out.push(String.fromCharCode(((c & 3) << 6) | d));
        }
        return out.join("");
    }

    function parsePath(d) {
        var t = d.match(/[MLCQZ]|-?\d*\.?\d+(?:e[-+]?\d+)?/gi) || [];
        var shapes = [], cur = null, i = 0, cmd, px = 0, py = 0;
        function num() { return parseFloat(t[i++]); }
        function addV(x, y) { cur.vertices.push([x, y]); cur.inTangents.push([0, 0]); cur.outTangents.push([0, 0]); px = x; py = y; }
        function curve(x1, y1, x2, y2, x, y) {
            cur.outTangents[cur.outTangents.length - 1] = [x1 - px, y1 - py];
            addV(x, y);
            cur.inTangents[cur.inTangents.length - 1] = [x2 - x, y2 - y];
        }
        function close() {
            if (!cur) return;
            var v = cur.vertices, n = v.length;
            if (n > 1 && v[0][0] == v[n - 1][0] && v[0][1] == v[n - 1][1]) {
                cur.inTangents[0] = cur.inTangents[n - 1];
                v.pop(); cur.inTangents.pop(); cur.outTangents.pop();
            }
            cur.closed = true; shapes.push(cur); cur = null;
        }
        while (i < t.length) {
            if (/[MLCQZ]/i.test(t[i])) cmd = t[i++].toUpperCase();
            if (cmd == "M") { if (cur) shapes.push(cur); cur = { vertices: [], inTangents: [], outTangents: [], closed: false }; addV(num(), num()); cmd = "L"; }
            else if (cmd == "L") addV(num(), num());
            else if (cmd == "C") curve(num(), num(), num(), num(), num(), num());
            else if (cmd == "Q") {
                var qx = num(), qy = num(), x = num(), y = num();
                curve(px + 2 / 3 * (qx - px), py + 2 / 3 * (qy - py), x + 2 / 3 * (qx - x), y + 2 / 3 * (qy - y), x, y);
            }
            else if (cmd == "Z") close();
            else i++;
        }
        if (cur) shapes.push(cur);
        return shapes;
    }

    function toShape(o) {
        var s = new Shape();
        s.vertices = o.vertices; s.inTangents = o.inTangents; s.outTangents = o.outTangents; s.closed = o.closed;
        return s;
    }

    function applyCommon(layer, L) {
        layer.name = L.name;
        layer.transform.opacity.setValue(Math.max(0, Math.min(100, L.opacity)));
        if (L.blend && L.blend != "NORMAL" && BlendingMode[L.blend] !== undefined) layer.blendingMode = BlendingMode[L.blend];
    }

    function addShapeLayer(comp, L) {
        var layer = comp.layers.addShape();
        applyCommon(layer, L);
        layer.transform.position.setValue([L.x, L.y]);
        layer.transform.rotation.setValue(L.rot);
        var grp = layer.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
        var c = grp.property("ADBE Vectors Group"), g = L.geo, i;
        if (g.type == "rect") {
            var r = c.addProperty("ADBE Vector Shape - Rect");
            r.property("ADBE Vector Rect Size").setValue([L.w, L.h]);
            r.property("ADBE Vector Rect Position").setValue([L.w / 2, L.h / 2]);
            r.property("ADBE Vector Rect Roundness").setValue(g.r || 0);
        } else if (g.type == "ellipse") {
            var e = c.addProperty("ADBE Vector Shape - Ellipse");
            e.property("ADBE Vector Ellipse Size").setValue([L.w, L.h]);
            e.property("ADBE Vector Ellipse Position").setValue([L.w / 2, L.h / 2]);
        } else {
            var count = 0;
            for (i = 0; i < g.paths.length; i++) {
                var subs = parsePath(g.paths[i]);
                for (var k = 0; k < subs.length; k++) {
                    c.addProperty("ADBE Vector Shape - Group").property("ADBE Vector Shape").setValue(toShape(subs[k]));
                    count++;
                }
            }
            if (count > 1) c.addProperty("ADBE Vector Filter - Merge").property("ADBE Vector Merge Type").setValue(5);
        }
        for (i = 0; i < L.strokes.length; i++) {
            var s = L.strokes[i], st = c.addProperty("ADBE Vector Graphic - Stroke");
            st.property("ADBE Vector Stroke Color").setValue([s.c[0], s.c[1], s.c[2], 1]);
            st.property("ADBE Vector Stroke Width").setValue(s.weight);
            st.property("ADBE Vector Stroke Opacity").setValue(s.o);
            st.property("ADBE Vector Stroke Line Cap").setValue(s.cap);
            st.property("ADBE Vector Stroke Line Join").setValue(s.join);
        }
        for (i = 0; i < L.fills.length; i++) {
            var f = L.fills[i], fl = c.addProperty("ADBE Vector Graphic - Fill");
            fl.property("ADBE Vector Fill Color").setValue([f.c[0], f.c[1], f.c[2], 1]);
            fl.property("ADBE Vector Fill Opacity").setValue(f.o);
        }
    }

    function addTextLayer(comp, L) {
        var layer = comp.layers.addBoxText([Math.max(L.w, 1), Math.max(L.h, 1)]);
        applyCommon(layer, L);
        var prop = layer.property("Source Text"), doc = prop.value;
        doc.resetCharStyle();
        doc.fontSize = L.size;
        doc.font = L.font;
        doc.applyFill = true; doc.fillColor = L.color;
        doc.applyStroke = false;
        doc.tracking = L.tracking;
        if (L.leading) { doc.autoLeading = false; doc.leading = L.leading; }
        doc.justification = L.align == "CENTER" ? ParagraphJustification.CENTER_JUSTIFY :
            L.align == "RIGHT" ? ParagraphJustification.RIGHT_JUSTIFY : ParagraphJustification.LEFT_JUSTIFY;
        doc.text = L.text.replace(/\n/g, "\r");
        prop.setValue(doc);
        layer.transform.position.setValue([L.x, L.y]);
        layer.transform.rotation.setValue(L.rot);
    }

    function addRasterLayer(comp, L, dir, idx) {
        var f = new File(dir.fsName + "/layer_" + idx + ".png");
        f.encoding = "BINARY"; f.open("w"); f.write(decodeBase64(L.png)); f.close();
        var item = app.project.importFile(new ImportOptions(f));
        item.parentFolder = comp.parentFolder;
        var layer = comp.layers.add(item);
        applyCommon(layer, L);
        layer.transform.anchorPoint.setValue([item.width / 2, item.height / 2]);
        layer.transform.position.setValue([L.x + L.w / 2, L.y + L.h / 2]);
        layer.transform.scale.setValue([100 / L.scale, 100 / L.scale]);
    }

    function importFile(file, fps, duration) {
        file.encoding = "UTF-8"; file.open("r");
        var raw = file.read(); file.close();
        var data = eval("(" + raw + ")");
        var dir = new Folder(file.parent.fsName + "/" + file.displayName.replace(/\.[^.]*$/, "") + "_assets");
        if (!dir.exists) dir.create();
        app.beginUndoGroup("Figma import");
        try {
            var folder = app.project.items.addFolder(data.name || "Figma");
            for (var fi = 0; fi < data.frames.length; fi++) {
                var fr = data.frames[fi];
                var comp = app.project.items.addComp(fr.name, Math.max(fr.w, 4), Math.max(fr.h, 4), 1, duration, fps);
                comp.parentFolder = folder;
                for (var li = 0; li < fr.layers.length; li++) {
                    var L = fr.layers[li];
                    try {
                        if (L.kind == "shape") addShapeLayer(comp, L);
                        else if (L.kind == "text") addTextLayer(comp, L);
                        else addRasterLayer(comp, L, dir, fi + "_" + li);
                    } catch (err) {
                        $.writeln("Layer '" + L.name + "' failed: " + err);
                    }
                }
            }
        } finally { app.endUndoGroup(); }
    }

    function buildUI(thisObj) {
        var w = thisObj instanceof Panel ? thisObj : new Window("palette", "Figma → AE", undefined, { resizeable: true });
        w.orientation = "column"; w.alignChildren = ["fill", "top"];
        var row1 = w.add("group"); row1.add("statictext", undefined, "FPS:");
        var fps = row1.add("edittext", undefined, "30"); fps.characters = 4;
        row1.add("statictext", undefined, "Длина, с:");
        var dur = row1.add("edittext", undefined, "5"); dur.characters = 4;
        var btn = w.add("button", undefined, "Импорт figma-to-ae.json…");
        btn.onClick = function () {
            if (!app.project) app.newProject();
            var f = File.openDialog("Выберите JSON из Figma-плагина", "JSON:*.json");
            if (f) importFile(f, parseFloat(fps.text) || 30, parseFloat(dur.text) || 5);
        };
        w.layout.layout(true);
        return w;
    }

    var ui = buildUI(thisObj);
    if (ui instanceof Window) { ui.center(); ui.show(); }
})(this);
