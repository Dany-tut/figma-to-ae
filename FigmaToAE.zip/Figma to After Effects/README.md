# Figma → After Effects

## Figma-плагин (3 вкладки)
- **Perspective** — Скос (нативно, слой остаётся векторным) и Corner pin (4 угла, на выходе слой-картинка).
- **Warp** — сетка 3×3, на выходе слой-картинка.
- **Export** — сводка и экспорт JSON для AE.

Figma → Plugins → Development → Import plugin from manifest… → `figma-plugin/manifest.json`.
Выделите фреймы → «Экспорт в JSON» → скачается `figma-to-ae.json`.

## After Effects
Положите `ae-script/FigmaToAE.jsx` в `Scripts/ScriptUI Panels`, включите
Preferences → Scripting & Expressions → «Allow Scripts to Write Files…», откройте через меню Window.
Нажмите «Импорт…» и выберите JSON. На каждый фрейм создаётся композиция.

## Что переносится
- Нативными слоями: прямоугольники (радиус), эллипсы, векторы/булевы/звёзды (путь), фреймы с заливкой, текст (шрифт, размер, цвет, выравнивание, трекинг), прозрачность, режимы наложения, поворот.
- Растром PNG (чтобы выглядело как в Figma): градиенты, картинки, эффекты (тени/блюр), маски, **скос/перспектива/зеркало** (результат Perspective Toolkit и Warp It), смешанный текст, дуги.
- Не переносится: clip-маски фреймов, auto-layout как логика, анимации.
