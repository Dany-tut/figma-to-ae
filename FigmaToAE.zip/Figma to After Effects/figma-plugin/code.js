figma.showUI(__html__, { width: 360, height: 760, themeColors: true });

function sendSelection() {
  const c = { native: 0, raster: 0 };
  const ctx = { ox: 0, oy: 0, opts: { scale: 2, rasterText: false } };
  figma.currentPage.selection.forEach(n => countNode(n, ctx, c));
  figma.ui.postMessage({ type: 'selection', count: figma.currentPage.selection.length, native: c.native, raster: c.raster });
}

function countNode(node, ctx, c) {
  if (node.visible === false) return;
  if (needsRaster(node, ctx)) { c.raster++; return; }
  if (CONTAINERS.includes(node.type)) node.children.forEach(ch => countNode(ch, ctx, c));
  else c.native++;
}

const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
function toBase64(bytes) {
  let out = '';
  for (let i = 0; i < bytes.length; i += 3) {
    const a = bytes[i], b = bytes[i + 1] || 0, c = bytes[i + 2] || 0;
    out += B64[a >> 2] + B64[((a & 3) << 4) | (b >> 4)] +
      (i + 1 < bytes.length ? B64[((b & 15) << 2) | (c >> 6)] : '=') +
      (i + 2 < bytes.length ? B64[c & 63] : '=');
  }
  return out;
}

const CONTAINERS = ['FRAME', 'GROUP', 'COMPONENT', 'INSTANCE', 'SECTION', 'COMPONENT_SET'];
const VECTORS = ['VECTOR', 'STAR', 'POLYGON', 'BOOLEAN_OPERATION'];
const rgb = c => [c.r, c.g, c.b];
const visiblePaints = p => (p === figma.mixed || !p ? null : p.filter(x => x.visible !== false));
const onlySolid = p => { const v = visiblePaints(p); return v !== null && v.every(x => x.type === 'SOLID'); };

function placement(node, ctx) {
  const [[a, c, tx], [b, d, ty]] = node.absoluteTransform;
  return {
    x: tx - ctx.ox, y: ty - ctx.oy,
    rot: Math.atan2(b, a) * 180 / Math.PI,
    skewed: Math.abs(a * c + b * d) > 1e-3 || a * d - b * c < 0,
  };
}

function hasEffects(n) { return 'effects' in n && n.effects.some(e => e.visible !== false); }

function needsRaster(node, ctx) {
  if (hasEffects(node) || node.isMask) return true;
  if ('children' in node && node.children.some(c => c.isMask)) return true;
  if ('fills' in node && !onlySolid(node.fills)) return true;
  if ('strokes' in node && !onlySolid(node.strokes)) return true;
  if (CONTAINERS.includes(node.type)) return false;
  if (placement(node, ctx).skewed) return true;
  if (node.type === 'RECTANGLE') return node.cornerRadius === figma.mixed;
  if (node.type === 'ELLIPSE') {
    const a = node.arcData;
    return a.innerRadius > 0 || Math.abs(a.endingAngle - a.startingAngle - Math.PI * 2) > 1e-4;
  }
  if (node.type === 'TEXT') {
    return ctx.opts.rasterText || node.fontSize === figma.mixed || node.fontName === figma.mixed ||
      !onlySolid(node.fills) || !visiblePaints(node.fills).length;
  }
  return !VECTORS.includes(node.type);
}

function paintList(paints) {
  return (visiblePaints(paints) || []).reverse().map(p => ({ c: rgb(p.color), o: (p.opacity === undefined ? 1 : p.opacity) * 100 }));
}

function strokeInfo(node) {
  if (!('strokes' in node)) return [];
  const w = node.strokeWeight === figma.mixed ? 1 : node.strokeWeight;
  return paintList(node.strokes).map(s => ({
    c: s.c, o: s.o, weight: w,
    cap: node.strokeCap === 'ROUND' ? 2 : node.strokeCap === 'SQUARE' ? 3 : 1,
    join: node.strokeJoin === 'ROUND' ? 2 : node.strokeJoin === 'BEVEL' ? 3 : 1,
  }));
}

async function raster(node, ctx, opacity) {
  const bytes = await node.exportAsync({ format: 'PNG', constraint: { type: 'SCALE', value: ctx.opts.scale } });
  const r = node.absoluteRenderBounds || node.absoluteBoundingBox;
  return {
    kind: 'raster', name: node.name, x: r.x - ctx.ox, y: r.y - ctx.oy, w: r.width, h: r.height,
    scale: ctx.opts.scale, opacity: ctx.opacity * 100, blend: 'NORMAL', png: toBase64(bytes),
  };
}

async function walk(node, ctx, out) {
  if (node.visible === false) return;
  const opacity = ctx.opacity * ('opacity' in node ? node.opacity : 1);

  if (needsRaster(node, ctx)) {
    ctx.stats.raster++;
    out.push(await raster(node, ctx, opacity));
    return;
  }

  const p = placement(node, ctx);
  const base = {
    name: node.name, x: p.x, y: p.y, rot: p.rot, w: node.width, h: node.height,
    opacity: opacity * 100, blend: node.blendMode === 'PASS_THROUGH' ? 'NORMAL' : node.blendMode,
  };

  if (node.type === 'TEXT') {
    const lh = node.lineHeight;
    const color = visiblePaints(node.fills)[0];
    out.push(Object.assign(base, {
      kind: 'text', text: node.characters, size: node.fontSize,
      font: node.fontName.family.replace(/\s/g, '') + '-' + node.fontName.style.replace(/\s/g, ''),
      color: rgb(color.color), opacity: opacity * (color.opacity === undefined ? 1 : color.opacity) * 100,
      align: node.textAlignHorizontal,
      tracking: node.letterSpacing.unit === 'PIXELS' ? node.letterSpacing.value / node.fontSize * 1000 : node.letterSpacing.value * 10,
      leading: lh.unit === 'PIXELS' ? lh.value : lh.unit === 'PERCENT' ? node.fontSize * lh.value / 100 : null,
    }));
    return;
  }

  if (CONTAINERS.includes(node.type)) {
    const fills = paintList(node.fills || []), strokes = strokeInfo(node);
    if (node.type !== 'GROUP' && (fills.length || strokes.length)) {
      out.push(Object.assign({}, base, {
        kind: 'shape', geo: { type: 'rect', r: typeof node.cornerRadius === 'number' ? node.cornerRadius : 0 },
        fills, strokes,
      }));
    }
    for (const child of node.children) await walk(child, Object.assign({}, ctx, { opacity }), out);
    return;
  }

  let geo;
  if (node.type === 'RECTANGLE') geo = { type: 'rect', r: node.cornerRadius };
  else if (node.type === 'ELLIPSE') geo = { type: 'ellipse' };
  else {
    const fg = node.fillGeometry && node.fillGeometry.length ? node.fillGeometry : node.vectorPaths || [];
    geo = { type: 'path', paths: fg.map(g => g.data || g.path) };
  }
  out.push(Object.assign(base, { kind: 'shape', geo, fills: paintList(node.fills), strokes: strokeInfo(node) }));
}

// язык сообщений; присылает окно плагина
let LANG = 'ru';
const tr = (ru, en) => (LANG === 'en' ? en : ru);
figma.ui.on('message', msg => { if (msg.type === 'lang') { LANG = msg.lang === 'en' ? 'en' : 'ru'; if (msg.save) figma.clientStorage.setAsync('ui-lang', LANG).catch(() => {}); } });
// сохранённый выбор языка (переключатель RU/EN в окне)
figma.clientStorage.getAsync('ui-lang').then((l) => { if (l === 'en' || l === 'ru') { LANG = l; figma.ui.postMessage({ type: 'lang-pref', lang: l }); } }).catch(() => {});

figma.ui.on('message', async msg => {
  if (msg.type !== 'export') return;
  try {
    const frames = [];
    const stats = { raster: 0 };
    let total = 0;
    for (const root of figma.currentPage.selection) {
      figma.ui.postMessage({ type: 'status', text: 'Обработка: ' + root.name + '…' });
      const box = root.absoluteRenderBounds || root.absoluteBoundingBox;
      const ctx = { ox: box.x, oy: box.y, opacity: 1, opts: { scale: msg.scale, rasterText: msg.rasterText }, stats };
      const layers = [];
      await walk(root, ctx, layers);
      total += layers.length;
      frames.push({ name: root.name, w: Math.round(box.width), h: Math.round(box.height), layers });
    }
    figma.ui.postMessage({
      type: 'done', layers: total, filename: 'figma-to-ae.json',
      json: JSON.stringify({ version: 1, name: figma.root.name, frames }),
    });
  } catch (e) {
    figma.ui.postMessage({ type: 'error', text: String(e && e.message || e) });
  }
});

// ---- Perspective: native skew ----
const mul = (A, B) => [
  [A[0][0] * B[0][0] + A[0][1] * B[1][0], A[0][0] * B[0][1] + A[0][1] * B[1][1], A[0][0] * B[0][2] + A[0][1] * B[1][2] + A[0][2]],
  [A[1][0] * B[0][0] + A[1][1] * B[1][0], A[1][0] * B[0][1] + A[1][1] * B[1][1], A[1][0] * B[0][2] + A[1][1] * B[1][2] + A[1][2]],
];
let originals = {};
function applySkew(sxDeg, syDeg, rzDeg, local, txDeg, tyDeg) {
  const rz = (rzDeg || 0) * Math.PI / 180, co = Math.cos(rz), si = Math.sin(rz);
  const kx = Math.tan(sxDeg * Math.PI / 180), ky = Math.tan(syDeg * Math.PI / 180);
  const scx = Math.max(Math.cos((tyDeg || 0) * Math.PI / 180), 0.02), scy = Math.max(Math.cos((txDeg || 0) * Math.PI / 180), 0.02);
  const squash = scx !== 1 || scy !== 1;
  let applied = 0, failed = 0, err = '';
  for (const n of figma.currentPage.selection) {
    if (!('relativeTransform' in n)) { failed++; err = tr('нет трансформации', 'no transform'); continue; }
    if (squash && n.type === 'TEXT') { failed++; err = tr('текст не сжимается — переведите в кривые', 'text can’t be squashed — flatten it to vectors'); continue; }
    const base = originals[n.id] || (originals[n.id] = { T: n.relativeTransform, w: n.width, h: n.height });
    const O = base.T, w0 = base.w, h0 = base.h, w1 = w0 * scx, h1 = h0 * scy;
    try {
      if (n.width !== w0 || n.height !== h0 || squash) {
        n.relativeTransform = O;
        if ('resize' in n) n.resize(w0, h0);
      }
      const cx = O[0][0] * w0 / 2 + O[0][1] * h0 / 2 + O[0][2];
      const cy = O[1][0] * w0 / 2 + O[1][1] * h0 / 2 + O[1][2];
      let O2 = O;
      if (squash && 'resize' in n) {
        n.resize(Math.max(w1, 0.01), Math.max(h1, 0.01));
        O2 = mul(O, [[1, 0, (w0 - w1) / 2], [0, 1, (h0 - h1) / 2]]);
      }
      const lx = n.width / 2, ly = n.height / 2;
      const R = [[co, -si, 0], [si, co, 0]], K = [[1, kx, 0], [ky, 1, 0]];
      const L = mul(mul(mul([[1, 0, lx], [0, 1, ly]], R), K), [[1, 0, -lx], [0, 1, -ly]]);
      const S = mul(mul(mul([[1, 0, cx], [0, 1, cy]], R), K), [[1, 0, -cx], [0, 1, -cy]]);
      n.relativeTransform = local ? mul(O2, L) : mul(S, O2);
      applied++;
    } catch (e) { failed++; err = String(e.message || e).slice(0, 80); }
  }
  figma.ui.postMessage({ type: 'skewinfo', applied, failed, err });
}

// ---- Perspective on vector networks (stays vector) ----
let vecState = null;

function buildVec() {
  const leaves = [];
  expand(figma.currentPage.selection.slice(), leaves);
  const items = [];
  let skipped = 0, x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
  for (const n of leaves) {
    const rb = n.absoluteRenderBounds || n.absoluteBoundingBox;
    if (rb) { x0 = Math.min(x0, rb.x); y0 = Math.min(y0, rb.y); x1 = Math.max(x1, rb.x + rb.width); y1 = Math.max(y1, rb.y + rb.height); }
    if (n.type === 'VECTOR') items.push({ node: n, net: JSON.parse(JSON.stringify(n.vectorNetwork)), A: n.absoluteTransform });
    else skipped++;
  }
  vecState = { items, skipped, U: { cx: (x0 + x1) / 2, cy: (y0 + y1) / 2, w: x1 - x0, h: y1 - y0 } };
}

function project(p, m, U) {
  const d = Math.PI / 180;
  const x = p.x - U.cx, y = p.y - U.cy;
  const x1 = x + Math.tan(m.x * d) * y, y1 = Math.tan(m.y * d) * x + y;
  const co = Math.cos(m.z * d), si = Math.sin(m.z * d);
  const x2 = x1 * co - y1 * si, y2 = x1 * si + y1 * co;
  const rx = m.tx * d, ry = m.ty * d;
  const y3 = y2 * Math.cos(rx), z3 = y2 * Math.sin(rx);
  const x4 = x2 * Math.cos(ry) + z3 * Math.sin(ry), z4 = -x2 * Math.sin(ry) + z3 * Math.cos(ry);
  const D = m.dist * Math.max(U.w, U.h), f = D / (D + z4);
  return { x: U.cx + x4 * f, y: U.cy + y3 * f };
}

async function perspVec(m) {
  if (!vecState) buildVec();
  const { items, skipped, U } = vecState;
  let applied = 0, failed = skipped, err = skipped ? tr('не кривые — нажмите «Перевести в кривые»', 'not vectors — click “Flatten to vectors”') : '';
  for (const it of items) {
    const [[a, c, e], [b, d, f]] = it.A, det = a * d - b * c;
    const toAbs = p => ({ x: a * p.x + c * p.y + e, y: b * p.x + d * p.y + f });
    const toLoc = p => ({ x: (d * (p.x - e) - c * (p.y - f)) / det, y: (-b * (p.x - e) + a * (p.y - f)) / det });
    const map = p => toLoc(project(toAbs(p), m, U));
    const verts = it.net.vertices.map(v => Object.assign({}, v, map(v)));
    const segs = it.net.segments.map(s => {
      const v0 = it.net.vertices[s.start], v1 = it.net.vertices[s.end];
      const t0 = map({ x: v0.x + s.tangentStart.x, y: v0.y + s.tangentStart.y }), t1 = map({ x: v1.x + s.tangentEnd.x, y: v1.y + s.tangentEnd.y });
      return Object.assign({}, s, { tangentStart: { x: t0.x - verts[s.start].x, y: t0.y - verts[s.start].y }, tangentEnd: { x: t1.x - verts[s.end].x, y: t1.y - verts[s.end].y } });
    });
    try { await it.node.setVectorNetworkAsync({ vertices: verts, segments: segs, regions: it.net.regions }); applied++; }
    catch (er) { failed++; err = String(er.message || er).slice(0, 80); }
  }
  figma.ui.postMessage({ type: 'skewinfo', applied, failed, err });
}

async function perspReset() {
  if (!vecState) return;
  for (const it of vecState.items) { try { await it.node.setVectorNetworkAsync(it.net); } catch (e) { /* ignore */ } }
  vecState = null;
}

async function flattenLeaves() {
  const sel = figma.currentPage.selection.slice();
  const leaves = [];
  expand(sel, leaves);
  const made = [];
  let n = 0;
  for (const l of leaves) {
    if (l.type === 'VECTOR' || l.type === 'FRAME' || l.type === 'COMPONENT' || l.type === 'INSTANCE') continue;
    try { made.push(figma.flatten([l])); n++; } catch (e) { /* cannot flatten */ }
  }
  vecState = null;
  figma.notify(tr('Переведено в кривые: ', 'Flattened to vectors: ') + n);
  const keep = sel.filter(s => !s.removed);
  if (keep.length) figma.currentPage.selection = keep;
}

// ---- Perspective corner pin / Warp: shared mapping over a whole selection ----
let grabbed = null, previews = [], hiddenNodes = [], ghosted = [], lastApplied = null;

function expand(nodes, out) {
  for (const n of nodes) {
    if (n.visible === false) continue;
    const ownFill = n.type === 'FRAME' && 'fills' in n && n.fills !== figma.mixed && n.fills.some(f => f.visible !== false);
    if ((n.type === 'GROUP' || n.type === 'FRAME') && n.children.length && !ownFill) expand(n.children, out);
    else out.push(n);
  }
}

async function grab(layers, scale) {
  const sel = figma.currentPage.selection.slice();
  if (!sel.length) { figma.ui.postMessage({ type: 'image', empty: true }); return; }
  let nodes = [];
  if (layers) expand(sel, nodes); else nodes = sel.filter(n => n.visible !== false);
  nodes = nodes.slice(0, 80);
  const metas = [];
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
  for (const n of nodes) {
    const rb = n.absoluteRenderBounds || n.absoluteBoundingBox;
    if (!rb || !rb.width || !rb.height) continue;
    const blend = 'blendMode' in n ? n.blendMode : 'NORMAL', opacity = 'opacity' in n ? n.opacity : 1;
    const neutral = blend !== 'NORMAL' && blend !== 'PASS_THROUGH';
    let bytes;
    try {
      if (neutral) n.blendMode = 'NORMAL';
      if (opacity !== 1) n.opacity = 1;
      bytes = await n.exportAsync({ format: 'PNG', constraint: { type: 'SCALE', value: scale || 2 } });
    } finally {
      if (neutral) n.blendMode = blend;
      if (opacity !== 1) n.opacity = opacity;
    }
    metas.push({ n, rb, bytes, blend, opacity });
    x0 = Math.min(x0, rb.x); y0 = Math.min(y0, rb.y);
    x1 = Math.max(x1, rb.x + rb.width); y1 = Math.max(y1, rb.y + rb.height);
  }
  if (!metas.length) { figma.ui.postMessage({ type: 'image', empty: true }); return; }
  grabbed = { roots: sel, rootIds: sel.map(n => n.id).join(','), parent: sel[0].parent, U: { x: x0, y: y0 } };
  figma.ui.postMessage({
    type: 'image', U: { w: x1 - x0, h: y1 - y0 },
    theta: 'absoluteTransform' in sel[0] ? Math.atan2(sel[0].absoluteTransform[1][0], sel[0].absoluteTransform[0][0]) : 0,
    items: metas.map(m => ({ name: m.n.name, blend: m.blend, opacity: m.opacity, bytes: m.bytes, x: m.rb.x - x0, y: m.rb.y - y0, w: m.rb.width, h: m.rb.height })),
  });
}

function restoreGhost() {
  ghosted.forEach(g => { if (!g.n.removed) g.n.opacity = g.o; });
  ghosted = [];
}

function cleanStale() {
  const found = figma.currentPage.findAll(n => n.name.indexOf('⟲ preview') === 0);
  found.forEach(n => n.remove());
  return found.length;
}

function clearPreview(restore) {
  previews.forEach(n => { if (!n.removed) n.remove(); });
  previews = [];
  if (restore) { hiddenNodes.forEach(n => { if (!n.removed) n.visible = true; }); hiddenNodes = []; restoreGhost(); }
}

async function applyWarp(m) {
  if (!grabbed) return;
  clearPreview(!m.hide);
  const plain = m.preview && m.plain;
  const ghost = m.preview && m.ghost;
  if (!m.preview) restoreGhost();
  const rects = m.items.map(it => {
    const r = figma.createRectangle();
    r.name = it.name;
    r.resize(Math.max(it.w, 1), Math.max(it.h, 1));
    r.fills = [{ type: 'IMAGE', imageHash: figma.createImage(it.bytes).hash, scaleMode: 'FILL' }];
    r.x = grabbed.U.x + it.dx; r.y = grabbed.U.y + it.dy;
    if (!plain && it.blend && it.blend !== 'PASS_THROUGH') r.blendMode = it.blend;
    if (!plain && it.opacity !== undefined) r.opacity = it.opacity;
    return r;
  });
  const parent = grabbed.parent;
  const idx = Math.max(-1, ...grabbed.roots.map(n => n.parent === parent ? parent.children.indexOf(n) : -1));
  let node;
  if (rects.length > 1) node = figma.group(rects, parent, idx + 1);
  else {
    node = rects[0];
    const ax = node.x, ay = node.y;
    let frame = parent;
    while (frame && (frame.type === 'GROUP' || frame.type === 'BOOLEAN_OPERATION')) frame = frame.parent;
    parent.insertChild(idx + 1, node);
    const fa = frame && frame.absoluteTransform;
    if (fa) {
      const [[a, c2, e], [b2, d, f]] = fa, det = a * d - b2 * c2;
      node.relativeTransform = mul([[d / det, -c2 / det, (c2 * f - d * e) / det], [-b2 / det, a / det, (b2 * e - a * f) / det]], [[1, 0, ax], [0, 1, ay]]);
    }
  }
  const root = grabbed.roots.length === 1 ? grabbed.roots[0] : null;
  if (!plain && root && (root.type === 'GROUP' || root.type === 'FRAME') && 'blendMode' in root) {
    if (rects.length > 1) { node.blendMode = root.blendMode; node.opacity = root.opacity; }
    else {
      node.opacity = node.opacity * root.opacity;
      if (node.blendMode === 'NORMAL' && root.blendMode !== 'PASS_THROUGH') node.blendMode = root.blendMode;
    }
  }
  node.name = (m.preview ? '⟲ preview – ' : 'Perspective – ') + grabbed.roots[0].name;
  if (ghost) {
    grabbed.roots.forEach(r => { if ('opacity' in r && !ghosted.some(g => g.n === r)) { ghosted.push({ n: r, o: r.opacity }); r.opacity = r.opacity * 0.25; } });
  } else if (m.hide) grabbed.roots.forEach(r => { if (r.visible) { r.visible = false; hiddenNodes.push(r); } });
  if (m.preview) previews = [node];
  else {
    lastApplied = { node, hidden: hiddenNodes.slice(), roots: grabbed.roots.slice() };
    hiddenNodes = [];
    figma.currentPage.selection = [node];
  }
}

function peek(on) {
  ghosted.forEach(g => { if (!g.n.removed) g.n.opacity = on ? g.o : g.o * 0.25; });
  previews.forEach(n => { if (!n.removed) n.visible = !on; });
  hiddenNodes.forEach(n => { if (!n.removed) n.visible = on; });
}

function undoApply() {
  if (!lastApplied) return;
  if (!lastApplied.node.removed) lastApplied.node.remove();
  lastApplied.hidden.forEach(n => { if (!n.removed) n.visible = true; });
  const roots = lastApplied.roots.filter(n => !n.removed);
  lastApplied = null;
  if (roots.length) figma.currentPage.selection = roots;
}

figma.on('selectionchange', () => {
  vecState = null;
  const ids = figma.currentPage.selection.map(n => n.id).join(',');
  if (previews.length && (!grabbed || ids !== grabbed.rootIds)) clearPreview(true);
  originals = {}; sendSelection(); figma.ui.postMessage({ type: 'selchanged' });
});
sendSelection();

figma.ui.on('message', async msg => {
  if (msg.type === 'skew') applySkew(msg.x, msg.y, msg.z, msg.local, msg.tx, msg.ty);
  else if (msg.type === 'skew-reset') {
    for (const id in originals) {
      const n = await figma.getNodeByIdAsync(id), o = originals[id];
      if (n) { if ('resize' in n) n.resize(o.w, o.h); n.relativeTransform = o.T; }
    }
    originals = {};
  } else if (msg.type === 'grab') await grab(msg.layers, msg.scale);
  else if (msg.type === 'apply-warp') await applyWarp(msg);
  else if (msg.type === 'cancel-preview') clearPreview(true);
  else if (msg.type === 'peek') peek(msg.on);
  else if (msg.type === 'persp-vec') await perspVec(msg);
  else if (msg.type === 'persp-reset') await perspReset();
  else if (msg.type === 'flatten') await flattenLeaves();
  else if (msg.type === 'clean-stale') figma.notify(tr('Убрано зависших превью: ', 'Stuck previews removed: ') + cleanStale());
  else if (msg.type === 'undo-apply') undoApply();
});

cleanStale();
